
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class FoodItemTest {

    @Test
    public void testNameMethod() {
        FoodItem item = new FoodItem(1, "Pizza", 12.99, "A delicious pizza", "pizza.jpg");
        assertEquals("Pizza<br>", item.name());
    }

    @Test
    public void testPriceMethod() {
        FoodItem item = new FoodItem(1, "Pizza", 12.99, "A delicious pizza", "pizza.jpg");
        assertEquals("<br>RM12.99<br>", item.price());
    }

    @Test
    public void testDescriptionMethod() {
        FoodItem item = new FoodItem(1, "Pizza", 12.99, "A delicious pizza", "pizza.jpg");
        assertEquals("A delicious pizza<br>", item.description());
    }
}
