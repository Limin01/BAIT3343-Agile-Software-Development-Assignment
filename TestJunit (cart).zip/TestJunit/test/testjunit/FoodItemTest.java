/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package testjunit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author xydren
 */
public class FoodItemTest {
    
    public FoodItemTest() {
    }
    
    @BeforeEach
    public void setUp() {
    }

    /**
     * Test of name method, of class FoodItem.
     */
    @Test
    public void testName() {
        System.out.println("name");
        FoodItem instance = null;
        String expResult = "";
        String result = instance.name();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of price method, of class FoodItem.
     */
    @Test
    public void testPrice() {
        System.out.println("price");
        FoodItem instance = null;
        String expResult = "";
        String result = instance.price();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of description method, of class FoodItem.
     */
    @Test
    public void testDescription() {
        System.out.println("description");
        FoodItem instance = null;
        String expResult = "";
        String result = instance.description();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getId method, of class FoodItem.
     */
    @Test
    public void testGetId() {
        System.out.println("getId");
        FoodItem instance = null;
        int expResult = 0;
        int result = instance.getId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setId method, of class FoodItem.
     */
    @Test
    public void testSetId() {
        System.out.println("setId");
        int id = 0;
        FoodItem instance = null;
        instance.setId(id);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getName method, of class FoodItem.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        FoodItem instance = null;
        String expResult = "";
        String result = instance.getName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setName method, of class FoodItem.
     */
    @Test
    public void testSetName() {
        System.out.println("setName");
        String name = "";
        FoodItem instance = null;
        instance.setName(name);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPrice method, of class FoodItem.
     */
    @Test
    public void testGetPrice() {
        System.out.println("getPrice");
        FoodItem instance = null;
        double expResult = 0.0;
        double result = instance.getPrice();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setPrice method, of class FoodItem.
     */
    @Test
    public void testSetPrice() {
        System.out.println("setPrice");
        double price = 0.0;
        FoodItem instance = null;
        instance.setPrice(price);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDescription method, of class FoodItem.
     */
    @Test
    public void testGetDescription() {
        System.out.println("getDescription");
        FoodItem instance = null;
        String expResult = "";
        String result = instance.getDescription();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDescription method, of class FoodItem.
     */
    @Test
    public void testSetDescription() {
        System.out.println("setDescription");
        String description = "";
        FoodItem instance = null;
        instance.setDescription(description);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getImageUrl method, of class FoodItem.
     */
    @Test
    public void testGetImageUrl() {
        System.out.println("getImageUrl");
        FoodItem instance = null;
        String expResult = "";
        String result = instance.getImageUrl();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setImageUrl method, of class FoodItem.
     */
    @Test
    public void testSetImageUrl() {
        System.out.println("setImageUrl");
        String imageUrl = "";
        FoodItem instance = null;
        instance.setImageUrl(imageUrl);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
