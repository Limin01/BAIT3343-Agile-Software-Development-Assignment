/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testjunit;

import java.util.ArrayList;

/**
 *
 * @author xydren
 */
public class FoodItem {

    public int id;
    public String name;
    public double price;
    public String description;
    public String imageUrl;

    public FoodItem(int id, String name, double price, String description, String imageUrl) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.description = description;
        this.imageUrl = imageUrl;
    }

    public void initializeFoodMenu() {
        ArrayList<FoodItem> menu = new ArrayList<>();

        menu.add(new FoodItem(1001, "Hamburger", 5.99, "A juicy hamburger with your choice of toppings.", "images/hamburger.jpg"));
        menu.add(new FoodItem(1002, "Cheeseburger", 6.49, "A hamburger with cheese and your choice of toppings.", "images/cheeseburger.jpg"));
        menu.add(new FoodItem(1003, "French Fries", 2.99, "Crispy golden french fries.", "images/french_fries.jpg"));
        menu.add(new FoodItem(1004, "Onion Rings", 3.49, "Crispy golden onion rings.", "images/onion_rings.jpg"));
        menu.add(new FoodItem(1005, "Soft Drink", 1.99, "Your choice of soda or iced tea.", "images/soft_drink.jpeg"));

    }

    public String name() {
        return this.name + "<br>";
    }

    public String price() {
        return "<br>RM" + String.format("%.2f", this.price) + "<br>";
    }

    public String description() {
        return this.description + "<br>";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

}
