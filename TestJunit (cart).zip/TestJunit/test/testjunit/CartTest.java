
package testjunit;

import java.util.ArrayList;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class CartTest {
    
        ArrayList<FoodItem> foodlist = new ArrayList<>();
        
        FoodItem food = new FoodItem(1,"pizza",12.21, "delicious one", "pizza.jpg");
        FoodItem food2 = new FoodItem(2,"burger",15.51, "delicious two", "burger.jpg");
        
        private Cart c1,c2;
        
    public CartTest() {
        foodlist.add(food);
        foodlist.add(food2);
        c1 = new Cart(foodlist, 123.45, 5, "I need something.");
        c2 = null;
    }
    
    @Before
    public void setUp() {
    }

    /**
     * Test of getFoodcartList method, of class Cart.
     */
    @Test
    public void testGetFoodcartList() {
        System.out.println("getFoodcartList");
        ArrayList<FoodItem> expResult = new ArrayList<>();
        expResult.add(food);
        expResult.add(food2);
        ArrayList<FoodItem> result = c1.getFoodcartList();
        assertEquals(expResult, result);
        foodlist.add(food);
        foodlist.add(food2);
        assertEquals(foodlist, result);
    }

    /**
     * Test of setFoodcartList method, of class Cart.
     */
    @Test
    public void testSetFoodcartList() {
        
        
        System.out.println("setFoodcartList");
        ArrayList<FoodItem> foodcartList = new ArrayList<>();
        foodcartList.add(food);
        foodcartList.add(food2);
        c1.setFoodcartList(foodcartList);
        
    }

    /**
     * Test of getPrice method, of class Cart.
     */
    @Test
    public void testGetPrice() {
        
        System.out.println("getPrice");
        double expResult = 123.45;
        double result = c1.getPrice();
        assertEquals(expResult, result, 0);
    }

    /**
     * Test of setPrice method, of class Cart.
     */
    @Test
    public void testSetPrice() {
        
        System.out.println("setPrice");
        double price = 123.12;
        c1.setPrice(price);
    }

    /**
     * Test of getQuantity method, of class Cart.
     */
    @Test
    public void testGetQuantity() {
        
        System.out.println("getQuantity");
        int expResult = 5;
        int result = c1.getQuantity();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of setQuantity method, of class Cart.
     */
    @Test
    public void testSetQuantity() {
        
        System.out.println("setQuantity");
        int quantity = 12;
        c1.setQuantity(quantity);
    }

    /**
     * Test of getRemark method, of class Cart.
     */
    @Test
    public void testGetRemark() {
        
        System.out.println("getRemark");
        //String expResult = "There is a request needed.";
        String expResult = "I need something.";
        String result = c1.getRemark();
        assertEquals(expResult, result);
    }

    /**
     * Test of setRemark method, of class Cart.
     */
    @Test
    public void testSetRemark() {

        
        System.out.println("setRemark");
        String remark = "I need more ice.";
        c1.setRemark(remark);
        
    }
    
}
