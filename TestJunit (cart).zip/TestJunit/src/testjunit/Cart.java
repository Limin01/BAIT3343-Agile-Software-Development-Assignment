/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testjunit;
import java.util.ArrayList;
import testjunit.FoodItem;
/**
 *
 * @author xydren
 */
public class Cart {
    private ArrayList<FoodItem> foodcartList;
    private double price;
    private int quantity;
    private String remark;

    public Cart(ArrayList<FoodItem> foodcartList, double price, int quantity, String remark) {
        this.foodcartList = foodcartList;
        this.price = price;
        this.quantity = quantity;
        this.remark = remark;
    }

    public Cart() {
        
    }

    public ArrayList<FoodItem> getFoodcartList() {
        return foodcartList;
    }

    public void setFoodcartList(ArrayList<FoodItem> foodcartList) {
        this.foodcartList = foodcartList;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    
    
}
